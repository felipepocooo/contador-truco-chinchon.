# Contador de Truco y Chinchón

Proyecto Android sencillo con marcador manual para dos equipos.

## Funciones
- Truco: partida a 15 o 30 puntos.
- Chinchón: límite de 50, 70 o 100 puntos.
- Sumar +1 o +5 a Nosotros y Ellos.
- Deshacer la última suma.
- Reiniciar con confirmación.
- Guarda automáticamente el marcador y la configuración en el teléfono.
- Aviso cuando un equipo alcanza el objetivo.
- Versión HTML incluida como vista alternativa.

## Importante
Este ZIP contiene el código fuente del proyecto, NO un APK compilado.
El tamaño final de la app depende de la herramienta de compilación y de las dependencias.
El límite de 50 MB es un objetivo máximo, no una garantía del tamaño final.

## Compilación
El proyecto usa Android Gradle Plugin. Para crear el APK se necesita una herramienta de compilación Android compatible.
