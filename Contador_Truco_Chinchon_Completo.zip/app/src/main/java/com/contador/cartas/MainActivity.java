package com.contador.cartas;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.ArrayList;

public class MainActivity extends Activity {
    int nosotros = 0, ellos = 0, objetivo = 30;
    String juego = "Truco";
    TextView scoreN, scoreE, estado;
    Spinner juegoSpinner, objetivoSpinner;
    SharedPreferences prefs;
    ArrayList<int[]> historial = new ArrayList<>();

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("marcador", MODE_PRIVATE);
        nosotros = prefs.getInt("nosotros", 0);
        ellos = prefs.getInt("ellos", 0);
        juego = prefs.getString("juego", "Truco");
        objetivo = prefs.getInt("objetivo", 30);
        construirInterfaz();
        actualizar();
    }

    TextView texto(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,35,35));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    Button boton(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    void construirInterfaz() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(242,247,243));

        TextView titulo = texto("🃏 CONTADOR DE CARTAS", 23, true);
        root.addView(titulo, new LinearLayout.LayoutParams(-1, dp(58)));

        juegoSpinner = new Spinner(this);
        String[] juegos = {"Truco", "Chinchón"};
        juegoSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, juegos));
        juegoSpinner.setSelection(juego.equals("Chinchón") ? 1 : 0);
        root.addView(juegoSpinner, new LinearLayout.LayoutParams(-1, dp(48)));

        objetivoSpinner = new Spinner(this);
        root.addView(objetivoSpinner, new LinearLayout.LayoutParams(-1, dp(48)));
        cargarObjetivos();

        LinearLayout scores = new LinearLayout(this);
        scores.setOrientation(LinearLayout.HORIZONTAL);
        scores.setGravity(Gravity.CENTER);
        scores.setWeightSum(2);

        LinearLayout nCol = new LinearLayout(this); nCol.setOrientation(LinearLayout.VERTICAL);
        nCol.setGravity(Gravity.CENTER); nCol.setPadding(dp(6),dp(8),dp(6),dp(8));
        nCol.setBackgroundColor(Color.rgb(215,239,224));
        LinearLayout eCol = new LinearLayout(this); eCol.setOrientation(LinearLayout.VERTICAL);
        eCol.setGravity(Gravity.CENTER); eCol.setPadding(dp(6),dp(8),dp(6),dp(8));
        eCol.setBackgroundColor(Color.rgb(255,228,218));

        nCol.addView(texto("NOSOTROS", 18, true));
        scoreN = texto("0", 54, true); nCol.addView(scoreN);
        Button n1 = boton("+1"); Button n5 = boton("+5");
        nCol.addView(n1); nCol.addView(n5);
        eCol.addView(texto("ELLOS", 18, true));
        scoreE = texto("0", 54, true); eCol.addView(scoreE);
        Button e1 = boton("+1"); Button e5 = boton("+5");
        eCol.addView(e1); eCol.addView(e5);

        scores.addView(nCol, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, -2, 1); ep.leftMargin = dp(8);
        scores.addView(eCol, ep);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(12); root.addView(scores, sp);

        estado = texto("", 17, true);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, dp(52));
        st.topMargin = dp(8); root.addView(estado, st);

        Button undo = boton("↩ Deshacer última suma");
        Button reset = boton("Reiniciar partida");
        root.addView(undo, new LinearLayout.LayoutParams(-1, dp(50)));
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(50)));

        setContentView(root);

        n1.setOnClickListener(v -> sumar(0,1));
        n5.setOnClickListener(v -> sumar(0,5));
        e1.setOnClickListener(v -> sumar(1,1));
        e5.setOnClickListener(v -> sumar(1,5));
        undo.setOnClickListener(v -> deshacer());
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Reiniciar partida")
            .setMessage("¿Querés poner ambos marcadores en cero?")
            .setNegativeButton("Cancelar", (d,w)->{})
            .setPositiveButton("Reiniciar", (d,w)-> { nosotros=0; ellos=0; historial.clear(); guardar(); actualizar(); })
            .show());

        juegoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                String nuevo = pos == 0 ? "Truco" : "Chinchón";
                if (!nuevo.equals(juego)) { juego = nuevo; cargarObjetivos(); guardar(); actualizar(); }
            }
        });
        objetivoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                int nuevo;
                if (juego.equals("Truco")) nuevo = pos == 0 ? 15 : 30;
                else nuevo = pos == 0 ? 50 : (pos == 1 ? 70 : 100);
                if (nuevo != objetivo) { objetivo = nuevo; guardar(); actualizar(); }
            }
        });
    }

    void cargarObjetivos() {
        if (objetivoSpinner == null) return;
        String[] opts = juego.equals("Truco") ? new String[]{"A 15 puntos", "A 30 puntos"} : new String[]{"A 50 puntos", "A 70 puntos", "A 100 puntos"};
        objetivoSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, opts));
        int idx = 0;
        if (juego.equals("Truco")) idx = objetivo == 15 ? 0 : 1;
        else idx = objetivo == 50 ? 0 : (objetivo == 70 ? 1 : 2);
        objetivoSpinner.setSelection(idx);
    }

    void sumar(int equipo, int puntos) {
        if (nosotros >= objetivo || ellos >= objetivo) return;
        historial.add(new int[]{nosotros, ellos});
        if (equipo == 0) nosotros += puntos; else ellos += puntos;
        guardar(); actualizar();
    }

    void deshacer() {
        if (historial.isEmpty()) { Toast.makeText(this, "No hay sumas para deshacer", Toast.LENGTH_SHORT).show(); return; }
        int[] prev = historial.remove(historial.size()-1);
        nosotros=prev[0]; ellos=prev[1]; guardar(); actualizar();
    }

    void actualizar() {
        if (scoreN == null) return;
        scoreN.setText(String.valueOf(nosotros));
        scoreE.setText(String.valueOf(ellos));
        String fin = nosotros >= objetivo ? "🏆 ¡Ganó Nosotros!" : (ellos >= objetivo ? "🏆 ¡Ganó Ellos!" : "Objetivo: " + objetivo + " puntos");
        estado.setText(fin);
    }

    void guardar() {
        prefs.edit().putInt("nosotros", nosotros).putInt("ellos", ellos)
            .putInt("objetivo", objetivo).putString("juego", juego).apply();
    }
}
